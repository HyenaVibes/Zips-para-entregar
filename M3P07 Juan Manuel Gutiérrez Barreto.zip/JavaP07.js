function Dado() {
let monedas = 50;
let resultados = []

while (monedas > 0 && monedas < 100) {
    alert ("Tienes" + monedas + "monedas");
    let cantidadmonedas = prompt("apuesta monedas el mínimo es uno");
    cantidadmonedas = parseInt(cantidadmonedas);
    if  ((isNaN(cantidadmonedas)) || cantidadmonedas < 1 || cantidadmonedas > monedas) {
        alert ("por favor introduce una cantidad correcta de monedas, mínimo una.");
        continue;
    }
    let apuesta = prompt("Elige la cara del dado 1-6");
    apuesta = parseInt(apuesta);
    if ((isNaN(apuesta))|| apuesta < 1 || apuesta > 6) {
        alert ("por favor elige un numero entre uno y seis");
    }
    let resultadodado = Math.floor (Math.random(1 - 6) * 6) + 1;

    alert ("Este es tu resultado" + resultadodado);
    resultados.push(resultadodado);
    if (resultadodado == apuesta) {
        monedas += cantidadmonedas;
        alert ("Acertaste has ganado" + cantidadmonedas + "monedas"); 
    }
        else { monedas -= cantidadmonedas; 
            alert ("Has fallado, has perdido" + cantidadmonedas + "te quedan" + monedas + "monedas");
        }
    if (monedas === 0)  {
        alert ("Game Over, te has quedado sin monedas");
        break;
    }  
    if (monedas === 100) {
        alert ("Enhorabuena has ganado el juego con" + monedas + "monedas")
        break;
    }
    }
    alert("Números que han salido: " + resultados.join(", "));
}


