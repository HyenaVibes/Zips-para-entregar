document.addEventListener('DOMContentLoaded', function () {
    document.getElementById('user-form').addEventListener('submit', function (event) {
        event.preventDefault();

    var username = document.getElementById('username').value;
    var email = document.getElementById('email').value;
    var password = document.getElementById('password').value;
    var confirmPassword = document.getElementById('confirm-password').value;

    var emailRegex = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;

    if (username.length < 4) {
        alert("El nombre de usuario debe tener al menos 4 caracteres.");
        return;
    }
    if (!emailRegex.test(email)) {
        alert("El correo electrónico no es válido.");
        return;
    }
    if (password.length < 6 || password.length > 12) {
        alert("La contraseña debe tener entre 6 y 12 caracteres.");
        return;
    }
    if (password !== confirmPassword) {
        alert("Las contraseñas no coinciden.");
        return;
    }
    alert("Formulario enviado.")
})
});
