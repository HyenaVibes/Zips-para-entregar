function pedirLetras() {
    let letras = ""
    let letra;

    while (letra !== null) {
        letra = prompt("Introduce una letra:");

        if (letra !== null) {
            if (letra.length === 1 && /^[a-zA-Z]$/.test(letra)) {
                letras += letra
                alert("Letra válida: " + letra);
            } else {
                alert("Por favor, introduce una sola letra.");
            }
        }
    }

    document.write("Programa finalizado." + letras);

}