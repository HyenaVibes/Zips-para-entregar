function almacenamientoLocal() {
    var clave = 'M4_UD2_P02';
    var valor = 'Nombre del Alumno';
    if (localStorage.getItem(clave) === null) {
        localStorage.setItem(clave, valor);
     } 
     else {
            alert("Ya existe un dato con la misma clave en el LocalStorage.");
        }
    
}
function almacenamientodeSesión() {
    var clave = 'Date'
    var valor = new Date().getTime().toString();
    sessionStorage.setItem(clave, valor);
}
function mostrarInformacion() {
    var infoLocalStorage = '';
    var infoSessionStorage = '';

    for (var i = 0; i < localStorage.length; i++) {
        var clave = localStorage.key(i);
        var valor = localStorage.getItem(clave);
        infoLocalStorage += 'Clave: ' + clave + ', Valor: ' + valor + '\n';
    }

    for (var j = 0; j < sessionStorage.length; j++) {
        var clave = sessionStorage.key(j);
        var valor = sessionStorage.getItem(clave);
        infoSessionStorage += 'Clave: ' + clave + ', Valor: ' + valor + '\n';
    }

    alert('Datos en localStorage:\n' + infoLocalStorage + '\nDatos en sessionStorage:\n' + infoSessionStorage);
}