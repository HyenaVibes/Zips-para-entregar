let personas = []
class Persona {
    constructor(nombre, apellido, edad) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.edad = edad;
    }   
}

function GenerarPersona() {
    for (let i = 0; i < 5; i++) {
        let nombre = prompt("Ingrese un Nombre:");
        let apellido = prompt("Ingrese Apellido:");
        let edad = parseInt(prompt("Ingrese edad:"));

        let persona = new Persona(nombre, apellido, edad);
        personas.push(persona);
    }
}

function MostrarPersona() {
    let lista = document.getElementById("ListaPersonas");
    lista.innerHTML = " ";
    personas.forEach(persona =>{
        let li = document.createElement("li");
        li.textContent = `Nombre: ${persona.nombre}, Apellido: ${persona.apellido}; Edad: ${persona.edad}`;
        lista.appendChild(li);
    })
}