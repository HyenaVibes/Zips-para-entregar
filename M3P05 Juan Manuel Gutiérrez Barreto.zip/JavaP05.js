function elegirMenu() {
    let primerplatoNumero = parseInt(prompt("Elige el número del Primer Plato (1-5):"));

    
    if (isNaN(primerplatoNumero)) {
        alert("Selección cancelada o no válida. Por favor, introduce números válidos (1-5) para los platos.");
        return;
    }

    let segundoplatoNumero = parseInt(prompt("Elige el número del Segundo Plato (1-5):"));

    
    if (isNaN(segundoplatoNumero)) {
        alert("Selección cancelada o no válida. Por favor, introduce números válidos (1-5) para los platos.");
        return;
    }

    if (primerplatoNumero < 1 || primerplatoNumero > 5 || segundoplatoNumero < 1 || segundoplatoNumero > 5) {
        alert("Por favor, introduce números válidos (1-5) para los platos.");
        return;
    }

    let primerplatoDescripcion = obtenerDescripcionPlato(primerplatoNumero, "primerosplatos");
    let segundoplatoDescripcion = obtenerDescripcionPlato(segundoplatoNumero, "segundosplatos");

    alert("Ha elegido de primer plato " + primerplatoDescripcion + " y de segundo plato " + segundoplatoDescripcion);
}

function obtenerDescripcionPlato(numero, tipoPlato) {
    let lista = document.getElementById(tipoPlato);
    let platoSeleccionado = lista.querySelector("li:nth-child(" + numero + ")").textContent.trim();
    return platoSeleccionado;
}
