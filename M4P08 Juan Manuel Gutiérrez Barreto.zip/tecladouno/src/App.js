import React, { useState } from 'react';
import './App.css';

function Button({ value, onClick}) {
  return <button onClick={onClick}>{value}</button>
}
function Keyboard({ onButtonClick }) {
  const alphabeth = 'ABCDEFGHIJKLMNÑOPQRSTUVWXYZ';
return (
  <div className='keyboard'>
    {[...alphabeth].map(letter =>(
      <Button key={letter} value={letter} onClick={() => onButtonClick(letter)} />
    ))}
    <Button value=" " onClick={() => onButtonClick('')} />
    <Button value="←" onClick={() => onButtonClick('backspace')} />
  </div>
);
}
function Result({ value }) {
  return <div className='result'>{value}</div>;
}
function App() {
  const [result, setResult] = useState('');
  const handleButtonClick = (buttonValue) => {
    if (buttonValue === 'backspace') {
      setResult(prevResult => prevResult.slice(0, -1));
    }
    else {
      setResult(prevResult => prevResult + buttonValue);
    }
  };
  return (
    <div className='App'>
      <hi>Mi Teclado</hi>
      <Result value={result} />
      <Keyboard onButtonClick={handleButtonClick} />
    </div>
  );
}
export default App;
