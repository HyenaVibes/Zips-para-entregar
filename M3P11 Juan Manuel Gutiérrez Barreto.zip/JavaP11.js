document.addEventListener("DOMContentLoaded", function() {
    mostrarFechaHora();
})
function mostrarFechaHora() {
    const díasSemana = ["Domingo", "Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sabado"];
    const meses = ["Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"];
    const fechaActual = new Date();
    const díaSemana = díasSemana[fechaActual.getDay()];
    const día = fechaActual.getDate();
    const mes = meses[fechaActual.getMonth()];
    const año = fechaActual.getFullYear();
    let hora = fechaActual.getHours();
    let minutos = fechaActual.getMinutes();

    minutos = minutos < 10 ? "0" + minutos : minutos;
    const amPM = hora >= 12 ? 'p.m' : 'a.m';

    const mensaje = `Hoy es ${díaSemana}, ${día} de ${mes} de ${año} y son las ${hora}:${minutos} ${amPM} horas.`
    const elementoFechaHora = document.getElementById("fechaHora");
    elementoFechaHora.textContent = mensaje
}