function factorial(numero) {
    if (numero === 0 || numero === 1) {
        return 1;
    } else {
        return numero * factorial(numero - 1);
    }
}

function calcularfactorial () {
    let numero = parseInt(prompt("Introduce un numero entre 0 y 10"));
    while ( numero < 0 || numero > 10 || isNaN(numero)) {
        alert("numero incorrecto, debe ser entre 0 y 10");
        numero = parseInt(prompt("Introduce un numero entre 0 y 10"));
    }
    let resultadofactorial = factorial(numero);
    alert("El factorial de" + numero + "es" + resultadofactorial);
}
calcularfactorial();