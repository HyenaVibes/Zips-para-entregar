let AreadelCuadrado = 6*6
let AreaTriangulo = (6*4)/2
console.log(AreaTriangulo);
console.log(AreadelCuadrado);