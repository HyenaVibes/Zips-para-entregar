function mostrarNumeroEnlaces() {
    var enlaces = document.getElementsByTagName('a').length;
    alert("Numero de enlaces a pagina" + enlaces);
}
function mostrarPenultimoEnlace(){
    var enlaces = document.getElementsByTagName('a');
    if (enlaces.length >= 2) {
    var penultimoEnlace = enlaces[enlaces.length - 2].getAttribute('href');
        alert("Dirección del penúltimo enlace: " + penultimoEnlace);
    } else {
        alert("No hay suficientes enlaces en la página para obtener el penúltimo.");
    }
    }
function enlacesdeTwitter(){
    var enlacesTwitter = document.querySelectorAll('a[href="https://www.twitter.com"]').length;
    alert("Numero de enlaces a Twitter" + enlacesTwitter);
}
function enlacesParrafoTres(){
    var tercerParrafo = document.getElementsByTagName('p')[2];
    var enlacesTercerParrafo = tercerParrafo.getElementsByTagName('a').length;
    alert("Numero de enlaces en el Tercer Parrafo" + enlacesTercerParrafo);
}
function resetearInformación(){
    console.clear();
}
function ocultarInformación(){
    var infoDiv = document.getElementById('información');
    infoDiv.style.display = 'none';
}
function otraFunción(){}