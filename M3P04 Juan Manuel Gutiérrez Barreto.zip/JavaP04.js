document.addEventListener("DOMContentLoaded", function () {
    var notasInput = document.getElementById("notasInput");
    var resultadoMedia = document.getElementById("resultadoMedia");
    var resultadoCorrespondencia = document.getElementById("resultadoCorrespondencia");

    function calcularMedia() {
        var notas = notasInput.value.split(",").map(function (nota) {
            return parseFloat(nota.trim());
        });

        var sum = 0;
        for (var i = 0; i < notas.length; i++) {
            sum += notas[i];
        }

        var media = sum / notas.length;
        resultadoMedia.innerHTML = "La media de las notas es: " + media.toFixed(2);
    }

    function mostrarCorrespondencia() {
        var notaMedia = parseFloat(resultadoMedia.innerHTML.split(":")[1]);
        if (isNaN(notaMedia)) {
            alert("Primero calcula la media de las notas.");
            return;
        }

        if (notaMedia >= 0 && notaMedia < 3) {
            resultadoCorrespondencia.innerHTML = "Corresponde a: Muy deficiente";
        } else if (notaMedia >= 3 && notaMedia < 5) {
            resultadoCorrespondencia.innerHTML = "Corresponde a: Insuficiente";
        } else if (notaMedia >= 5 && notaMedia < 6) {
            resultadoCorrespondencia.innerHTML = "Corresponde a: Suficiente";
        } else if (notaMedia >= 6 && notaMedia < 7) {
            resultadoCorrespondencia.innerHTML = "Corresponde a: Bien";
        } else if (notaMedia >= 7 && notaMedia < 9) {
            resultadoCorrespondencia.innerHTML = "Corresponde a: Notable";
        } else if (notaMedia >= 9 && notaMedia <= 10) {
            resultadoCorrespondencia.innerHTML = "Corresponde a: Sobresaliente";
        }
    }

    window.calcularMedia = calcularMedia;
    window.mostrarCorrespondencia = mostrarCorrespondencia;
});
